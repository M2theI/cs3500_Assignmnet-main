package cs3500.pawnsboard.view;

import cs3500.pawnsboard.model.Card;
import cs3500.pawnsboard.model.CardImp;
import cs3500.pawnsboard.model.PawnsBoardModel;
import cs3500.pawnsboard.model.PawnsBoardModelImpl;
import cs3500.pawnsboard.model.PawnsBoardModel.Player;
import cs3500.pawnsboard.model.PawnsBoardModel.CellContent;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Tests for the PawnsBoardTextView class.
 */
public class PawnsBoardTextViewTest {

  private PawnsBoardModel model;
  private PawnsBoardTextView view;
  private List<Card> redDeck;
  private List<Card> blueDeck;

  /**
   * Create a card with the specified properties and a standard influence grid.
   */
  private Card createCard(String name, int cost, int valueScore) {
    String[] influenceGrid = {
            "XXXXX",
            "XXIXX",
            "XICIX",
            "XXIXX",
            "XXXXX"
    };
    return new CardImp(name, cost, valueScore, influenceGrid);
  }

  /**
   * Set up test fixtures.
   */
  @Before
  public void setUp() {
    model = new PawnsBoardModelImpl();

    // Create decks
    redDeck = new ArrayList<>();
    blueDeck = new ArrayList<>();

    // Add some cards with cost 1
    for (int i = 0; i < 10; i++) {
      redDeck.add(createCard("RedCost1Card" + i, 1, i + 1));
      blueDeck.add(createCard("BlueCost1Card" + i, 1, i + 1));
    }

    // Add some cards with cost 2
    for (int i = 0; i < 10; i++) {
      redDeck.add(createCard("RedCost2Card" + i, 2, i + 2));
      blueDeck.add(createCard("BlueCost2Card" + i, 2, i + 2));
    }

    // Add some cards with cost 3
    for (int i = 0; i < 10; i++) {
      redDeck.add(createCard("RedCost3Card" + i, 3, i + 3));
      blueDeck.add(createCard("BlueCost3Card" + i, 3, i + 3));
    }

    // Initialize the model
    model.initGame(3, 5, redDeck, blueDeck, 5);

    // Initialize the view
    view = new PawnsBoardTextView(model);
  }

  /**
   * Test constructor with null model.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testConstructorWithNullModel() {
    new PawnsBoardTextView(null);
  }

  /**
   * Test the toString method for the initial state.
   */
  @Test
  public void testToString_InitialState() {
    model.startGame();

    String expected = "Current Board State:\n" +
            "0 1___1 0\n" +
            "0 1___1 0\n" +
            "0 1___1 0";

    assertEquals(expected, view.toString());
  }

  /**
   * Test the toString method after placing a card.
   */
  @Test
  public void testToString_AfterPlacingCard() {
    model.startGame();

    // Find a card with cost 1 in Red's hand
    List<Card> redHand = model.getPlayerHand(Player.RED);
    int cardIndex = -1;
    for (int i = 0; i < redHand.size(); i++) {
      if (redHand.get(i).getCost() == 1) {
        cardIndex = i;
        break;
      }
    }

    if (cardIndex >= 0) {
      // Place the card at (0, 0)
      model.placeCard(cardIndex, 0, 0);

      // The cell at (0, 0) should now contain a Red card
      String expected = "Current Board State:\n" +
              "0 R___1 0\n" +
              "0 1___1 0\n" +
              "0 1___1 0";

      assertEquals(expected, view.toString());
    }
  }

  /**
   * Test the toString method for a more complex board state.
   */
  @Test
  public void testToString_ComplexState() {
    model.startGame();

    // We need to manually set up a complex board state
    // First, find cards with cost 1 in each player's hand
    List<Card> redHand = model.getPlayerHand(Player.RED);
    int redCardIndex = -1;
    for (int i = 0; i < redHand.size(); i++) {
      if (redHand.get(i).getCost() == 1) {
        redCardIndex = i;
        break;
      }
    }

    if (redCardIndex >= 0) {
      // Place Red's card at (0, 0)
      model.placeCard(redCardIndex, 0, 0);

      // Now it's Blue's turn - find a card with cost 1
      List<Card> blueHand = model.getPlayerHand(Player.BLUE);
      int blueCardIndex = -1;
      for (int i = 0; i < blueHand.size(); i++) {
        if (blueHand.get(i).getCost() == 1) {
          blueCardIndex = i;
          break;
        }
      }

      if (blueCardIndex >= 0) {
        // Place Blue's card at (0, 4)
        model.placeCard(blueCardIndex, 0, 4);

        // Now the board should have a Red card at (0, 0) and a Blue card at (0, 4)
        String expected = "Current Board State:\n" +
                redHand.get(redCardIndex).getValueScore() + " R___B " + blueHand.get(blueCardIndex).getValueScore() + "\n" +
                "0 1___1 0\n" +
                "0 1___1 0";

        assertEquals(expected, view.toString());
      }
    }
  }

  /**
   * Test the displayTurnInfo method.
   */
  @Test
  public void testDisplayTurnInfo() {
    model.startGame();

    // Initially, it's Red's turn
    String turnInfo = view.displayTurnInfo();

    // The output should include "RED's turn" and list the cards in Red's hand
    assertTrue(turnInfo.contains("RED's turn"));

    List<Card> redHand = model.getPlayerHand(Player.RED);
    for (Card card : redHand) {
      assertTrue(turnInfo.contains(card.getName()));
      assertTrue(turnInfo.contains("Cost: " + card.getCost()));
      assertTrue(turnInfo.contains("Value: " + card.getValueScore()));
    }

    // Now let's check Blue's turn
    model.passTurn(); // Red passes, now it's Blue's turn

    turnInfo = view.displayTurnInfo();

    // The output should include "BLUE's turn" and list the cards in Blue's hand
    assertTrue(turnInfo.contains("BLUE's turn"));

    List<Card> blueHand = model.getPlayerHand(Player.BLUE);
    for (Card card : blueHand) {
      assertTrue(turnInfo.contains(card.getName()));
      assertTrue(turnInfo.contains("Cost: " + card.getCost()));
      assertTrue(turnInfo.contains("Value: " + card.getValueScore()));
    }
  }

  /**
   * Test that the view correctly renders different cell contents.
   */
  @Test
  public void testRenderingDifferentCellContents() {
    model.startGame();

    // Find a card with cost 1 in Red's hand
    List<Card> redHand = model.getPlayerHand(Player.RED);
    int cardIndex = -1;
    for (int i = 0; i < redHand.size(); i++) {
      if (redHand.get(i).getCost() == 1) {
        cardIndex = i;
        break;
      }
    }

    if (cardIndex >= 0) {
      // Place Red's card at (0, 0) - This creates:
      // - A card at (0, 0)
      // - A pawn at (0, 1) (due to influence)
      // - A pawn at (1, 0) with 2 pawns (original pawn plus influence)
      model.placeCard(cardIndex, 0, 0);

      String boardState = view.toString();

      // Check for a card ('R')
      assertTrue(boardState.contains("R"));

      // Check for a pawn with count 2
      assertTrue(boardState.contains("2"));

      // Cell (0, 1) should have a pawn with count 1
      assertEquals('1', getCellCharAt(boardState, 0, 1));

      // Cell (1, 0) should have a pawn with count 2
      assertEquals('2', getCellCharAt(boardState, 1, 0));
    }
  }

  /**
   * Helper method to get the character at a specific cell position in the board string.
   * This assumes the string has "Current Board State:\n" as a prefix and row scores.
   */
  private char getCellCharAt(String boardString, int row, int col) {
    String[] lines = boardString.split("\n");
    // Skip the "Current Board State:" line and account for row scores
    String rowString = lines[row + 1];
    // Each row starts with the row score (n + ' ')
    return rowString.charAt(2 + col); // 2 for "n " prefix
  }
}